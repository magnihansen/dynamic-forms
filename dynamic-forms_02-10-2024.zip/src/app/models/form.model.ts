export interface FormModel {
  username: string;
  phone: string;
}